To run the program

1. Open the terminal and enter the command
java -cp homework_1.jar problem1.Tokenization <path to the cranfield folder,eg ./Cranfield >



Output of the program:
Part 1
Total Number of tokens(including duplicates): 113182
Number of unique tokens: 6564
Average number of (including duplicates)token per document: 80.0
Average number of (distinct)token per document: 4.0
Number of tokens that occur only once: 2844
30 Most frequent tokens: 
1. the 9437
2. of 5964
3. and 3300
4. a 2861
5.  2618
6. to 2248
7. in 2191
8. is 2036
9. for 1667
10. are 1202
11. with 1110
12. at 906
13. by 860
14. flow 846
15. on 824
16. that 777
17. be 652
18. an 631
19. pressure 569
20. as 565
21. from 550
22. this 547
23. boundary 534
24. number 494
25. which 481
26. results 471
27. layer 470
28. mach 431
29. it 409
30. was 343



Part 2
Number of distinct stems: 4594
Number of stems that occur only once: 3442
30 most frequent stems
1. gener 14
2. deriv 9
3. oper 9
4. determin 8
5. continu 8
6. predict 8
7. comput 8
8. express 7
9. develop 7
10. investig 7
11. correct 7
12. separ 7
13. us 7
14. illustr 7
15. observ 7
16. compar 7
17. transform 6
18. measur 6
19. design 6
20. direct 6
21. engin 6
22. discuss 6
23. depend 6
24. estim 6
25. relat 6
26. alter 6
27. approxim 6
28. requir 6
29. rotat 6
30. effect 6
Average number of (distinct)stems per document: 52.0


